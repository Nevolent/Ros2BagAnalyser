# JetBrains frontend experiment

This directory is a separate frontend experiment. The application under `src/`,
its database, processors, source recordings, deployment, `archive/`, and saved
`snapshots/` are not used or changed by the experiment.

From the repository root, in WSL or another shell with Python 3 and FFmpeg:

```sh
python3 jetbrains/tectrace-project/jetbrains/serve.py
```

Open **http://127.0.0.1:4174/**. Stop with Ctrl+C. Use `--port` to choose another
local port. The server always binds to loopback. No Python packages are needed.
FFmpeg is already part of this project's toolchain; first startup creates two
small 12-second H.264/yuv420p test-pattern clips in the ignored `.fixtures/`
directory. No source recording is opened. The server serves only this frontend's
HTML/CSS/JS and its identity-checked synthetic API/media, not the repository.

All catalog and processing state is invented and held in server memory. It
survives browser navigation and reloads and is shared by local tabs; restarting
the server or choosing a scenario resets it. This is intentionally not a second
persistent application backend. Simulated jobs take about 18 seconds per output,
with one active job at a time. No ROS worker or production service runs.

## Try the connected workflow

1. Browse the nested **Synthetic** folders, search, and use the existing status
   and health filters. Folder collapse, the splitter, and the left rail work.
2. Select **Unprepared run**, then **Prepare selected**. Choose any non-empty
   subset of front, top, and IMU outputs. The result distinguishes queued,
   reused, active, and unavailable outputs. Repeating the request is idempotent.
3. Open **Processing**. Pause/resume/cancel the active job. Select queue rows
   to move them earlier/later or cancel them. Select a failure and retry it.
   Completed and canceled attempts have separate tabs. History loads further
   API batches when scrolled; no page-number controls were added.
4. Click a recording name to open its numeric Analyzer URL. Refresh/back/forward
   retain that recording. Use play, the full-recording seek bar, graph seek,
   zoom, reset, all six IMU axes, details toggle, and graph help.
5. Open **Settings** for live-update preferences, manual refresh, and synthetic
   scenarios. `mixed`, `empty`, `offline`, `scan-error`, `api-error`, and `slow`
   cover healthy and failure layouts. Scenario changes reset all local tabs'
   synthetic data. They never call the production API.

The mixed catalog has 24 invented recordings, including missing top-camera,
damaged, partial, failed, zero-duration, long-coverage-gap, and hostile-text
fixtures. Synthetic IMU data includes duplicate timestamps and a per-axis null
gap. The two camera test patterns are deliberately labeled synthetic.

## Boundary for a later backend port

`common.js` makes ordinary `fetch` requests to the **same-origin** API. It does
not override `fetch`, import synthetic data, or offer a remote backend switch.
The frontend uses the existing repository contracts:

| Interaction | API |
| --- | --- |
| Catalog, folders, saved scan facts | `GET /api/v1/catalog` |
| Explicit rescan | `POST /api/v1/catalog/rescan` |
| Selected preparation | `POST /api/v1/recordings/prepare` |
| Active job and counts | `GET /api/v1/processing/overview` |
| Queue, failures, history, canceled attempts | `GET /api/v1/processing/jobs?view=…&limit=100&cursor=…` |
| Active job controls | `POST /api/v1/processing/jobs/{id}/pause`, `/resume`, `/cancel` |
| Selected queue/retry controls | `POST /api/v1/processing/jobs/reorder`, `/cancel`, `/retry` |
| Recording metadata and outputs | `GET /api/v1/recordings/{id}` |
| IMU manifest | `GET /api/recordings/{id}/imu-series` |
| Camera and IMU artifacts | Exact identity-bound URLs returned by the API |

Search, filters, selection, splitter, panel visibility, graph metric, zoom,
playback, and seeking are browser interactions; they do not invent API writes.
API text is rendered with DOM text operations. Requested artifact URLs must
match the selected numeric recording and artifact identity. API errors retain
loaded catalog data, and processing controls use the server's allowed actions.
Progress stays indeterminate; estimates are explicitly approximate.

The browser clock controls both cameras with a 100 ms drift threshold. Coverage
is applied independently, duplicate IMU timestamps use the last sample, and null
values break the graph. Decimal epoch nanoseconds stay strings/BigInts until
conversion into relative display time. The experiment currently bounds the IMU
payload at 200,000 samples; larger production bundles require a separately
reviewed rendering/performance pass rather than silent truncation.

To port later, serve the three HTML documents and their referenced CSS/JS next
to the real same-origin API. Preserve their relative navigation and numeric
`analyzer.html?id=…` links, or adapt those links to the application's router.
Do **not** ship `serve.py`, `synthetic.py`, `.fixtures/`, or `experiment.js`.
Only `serve.py` injects `experiment.js`; its scenario controls and synthetic
badge are absent from the ordinary HTML documents. No production integration,
release, real-data acceptance, or API deployment has been performed here.

The shared wide-screen sizing in `brand.css` remains in place. `interaction.css`
adds only the functional dialogs, notices, job actions, timeline, and small
layout corrections to the three existing views. No summary-card dashboard,
extra analysis families, uploads, or unrelated production menus were ported.

## Verification

From this directory:

```sh
python3 -m unittest -v test_synthetic
node --test timeline.test.cjs
```

With the experiment server running, the existing repository Python environment
can validate HTTP results against the actual application Pydantic schemas:

```sh
../../../.venv/bin/python -m unittest -v test_contracts
```

`browser-check.cjs` uses Node's built-in WebSocket support and a separate headless
Chrome debugging session on localhost port 9223. With that session running:

```sh
node --experimental-websocket browser-check.cjs
```

The browser check resets synthetic state. It exercises connected requests,
folder navigation, filters, preparation, processing controls, Analyzer playback,
coverage, missing/zero-duration data, error recovery, and settings. It captures
2559×1399 and 1440×900 screenshots and a network/error report in ignored `.qa/`.

Verified locally: 10 synthetic-state tests, 3 timeline tests, 4 HTTP/schema test
cases, JavaScript syntax checks, and the browser flow with no runtime exceptions.
Screenshots were inspected at both sizes; at 2559px width, the toolbar measures
63.97px and the folder card 838.06px. Both camera consumers sought to 5.0s.
These checks cover synthetic behavior, not real recording synchronization,
large-catalog performance, interrupted media delivery, or deployment admission.

All work remains uncommitted for review. The next step is to review this
experimental UI, then separately approve any port into the actual application.
