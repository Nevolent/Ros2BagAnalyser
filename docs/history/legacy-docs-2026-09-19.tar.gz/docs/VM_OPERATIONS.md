# VM operations guide

## Purpose and current evidence

This is the short, day-to-day map of the ROS 2 Bag Analyser VM. It records the
repository-defined operating model so an operator does not need to rediscover
paths, service names, or release rules during routine work or an incident.

It is **not** a record that the VM has been commissioned. Hostnames, private
addresses, NAS export names, credentials, certificates, and actual evidence
remain outside Git in the approved private site record. Until that record and
the live Gate 0 review are complete, every live value in this guide is an
expected value, not a fact about a running VM.

For initial installation, a migration, firewall/mount change, real-source
acceptance, backup restore, or rollback, use the full
[NAS trial operator runbook](NAS_TRIAL_RUNBOOK.md). This guide intentionally
does not weaken those approval gates.

## Verified VM snapshot — 2026-09-02

The following non-secret facts were verified from an operator-provided,
read-only VM inspection on 2026-09-02. They are a dated snapshot, not a claim
that trial commissioning or engineer access is complete. The NAS endpoint,
credential names, and private network values remain in the private site record.

| Area | Verified fact |
|---|---|
| Active release | `/opt/rosbag-analyser/current` resolves to release `front-rgb8-e923aa8`. |
| VM platform | KVM guest running Ubuntu Server 22.04.5 LTS on x86-64 with the `5.15.0-190-generic` kernel. |
| Clock | UTC; NTP is enabled and synchronized. |
| API and worker | Both are running as `rosbag-analyser:rosbag-analyser`, from the active release, with the expected source read-only and derived read/write systemd restrictions. |
| Mounts | The source is a read-only CIFS mount at `/srv/rosbag-analyser/source`; derived storage is a separate read/write CIFS mount at `/var/lib/rosbag-analyser/derived`, rooted at the reserved cache subdirectory. |
| Preflight | The most recent preflight completed successfully, including release/schema, both mounts, capacity, ROS, FFmpeg/ffprobe, and derived atomic-rename checks. |
| Trial target/proxy | `rosbag-analyser.target` is enabled but currently inactive; API and worker were started independently. Nginx is masked. This is a controlled pre-admission state, not an engineer-facing trial. |
| Key directory permissions | `/opt/rosbag-analyser` and its releases/repository are `root:root 0755`; `/etc/rosbag-analyser` is `root:rosbag-analyser 0750`; source is `rosbag-analyser:rosbag-analyser 0550`; derived is `rosbag-analyser:rosbag-analyser 0750`; backup staging is `root:postgres 0750`. |
| Private-file permissions | `application.env` and `migration.env` are `root:rosbag-analyser 0640`; `backup.env`, all three `*.pgpass` files, and `source.cifs-credentials` are `root:root 0600`. |

The private site record still needs the remaining Gate 0 evidence: complete
package inventory, recovery/boot details, database-role evidence, listener/firewall
verification, backup/restore evidence, certificate/access ownership, and named
operational contacts.

## The system at a glance

```text
Developer workstation
  └─ clean, pushed Git revision
       └─ SSH operator
            └─ Ubuntu 22.04 VM
                 ├─ Nginx: private HTTPS entry point
                 ├─ FastAPI: loopback only, port 8000
                 ├─ PostgreSQL: local Unix socket or loopback only
                 ├─ one serial ROS worker
                 ├─ read-only CIFS source mount
                 └─ writable CIFS cache-subdirectory mount for derived output
```

The browser never reads the NAS directly. The API and worker read source data
only through the configured source mount. Generated artifacts are written only
below the derived mount. PostgreSQL stores metadata, not recording payloads or
generated media.

## Stable VM layout

| Purpose | Expected location | Owner and rule |
|---|---|---|
| Immutable installed releases | `/opt/rosbag-analyser/releases/<release-id>/` | Root-owned; never edit a release in place. |
| Active release pointer | `/opt/rosbag-analyser/current` | Atomic symlink to one installed release. |
| VM Git checkout | `/opt/rosbag-analyser/repository/` | Root-owned clean checkout; never run services from it. |
| Release staging | `/opt/rosbag-analyser/staging/` | Root-owned; used by controlled release installation. |
| Application configuration | `/etc/rosbag-analyser/` | Root-owned private configuration; never commit or print secrets. |
| Read-only source archive | `/srv/rosbag-analyser/source` | CIFS mount; application has no write path. Never list, repair, reindex, or write-probe it without approved real-data acceptance. |
| Derived cache mount | `/var/lib/rosbag-analyser/derived` | CIFS mount of the NAS `Rosbag_Analyser_Cache` subdirectory only. The service writes below its `rosbag-analyser/` child. |
| PostgreSQL socket | `/run/postgresql` | Local database access only. |
| Database backup staging | `/var/backups/rosbag-analyser` | Root/postgres controlled; off-VM protected copy is still required. |

The source and derived mounts are deliberately separate even when both are
backed by one NAS dataset. The source share is mounted read-only; the derived
mount addresses the cache subdirectory directly, so it cannot traverse upward
into source storage.

## Configuration and secrets

The expected private files are:

| File | Purpose | Handling |
|---|---|---|
| `/etc/rosbag-analyser/application.env` | Runtime roots, database role URL, topics, profile, mount identities, capacity limits, and loopback binding | `root:rosbag-analyser`, mode `0640`; no passwords in Git. |
| `/etc/rosbag-analyser/migration.env` | Migration database role URL | `root:rosbag-analyser`, mode `0640`. |
| `/etc/rosbag-analyser/backup.env` | Backup database role URLs | `root:root`, mode `0600`. |
| `/etc/rosbag-analyser/*.pgpass` | Database passwords | Root-owned, mode `0600`; do not display. |
| `/etc/rosbag-analyser/source.cifs-credentials` | CIFS credential | Root-owned, mode `0600`; do not display. |
| `/etc/rosbag-analyser/tls/` and `access/` | TLS and proxy-access material | Root-owned private material; do not commit or copy into support bundles. |

The committed examples in `deploy/` define the allowed keys and expected paths.
They contain placeholders, not active site values. Use the repository validator
and the controlled runbook to validate private files without printing them.

## Services and mounts

| Unit | Role | Normal state |
|---|---|---|
| `srv-rosbag\x2danalyser-source.mount` | Read-only source CIFS mount | Mounted before application preflight. |
| `var-lib-rosbag\x2danalyser-derived.mount` | Writable derived CIFS cache-subdirectory mount | Mounted before application preflight. |
| `postgresql.service` | Local metadata database | Running before application preflight. |
| `rosbag-analyser-preflight.service` | Validates release, schema, mounts, capacity, and dependencies | Successful before API/worker start. |
| `rosbag-analyser-api.service` | Loopback FastAPI service | Running; restart on failure. |
| `rosbag-analyser-worker.service` | Exactly one serial processing worker | Running; restart on failure. |
| `rosbag-analyser.target` | Groups preflight, API, and worker | Enabled only after approved commissioning/boot proof. |
| `nginx.service` | Private HTTPS reverse proxy | Starts only after local health and access checks pass. |

The API and worker both run as the non-login `rosbag-analyser` identity. They
may read the source mount and write the derived mount; they do not own releases,
configuration, database backup state, or NAS administration.

## Known current validation condition

The VM worker repeatedly rejected both generated front previews and IMU series
on 2026-09-01 while validating output in the writable CIFS-derived mount.
Preview attempts failed as `preview_output_changed`; IMU attempts failed as
`imu_series_validation_mismatch` after the internal `series changed during
validation` check. Source discovery was not implicated.

The current code compares device, inode, size, and nanosecond modification time
before and after output validation. CIFS timestamp finalization is the leading
explanation for this derived-output-only failure, but the existing log does not
name the changed field. The corrective work must first add a targeted
timestamp-only reproduction test, then retain real file identity, size, and
content validation while making derived CIFS timestamp finalization safe. Do
not weaken source-file identity checks.

## Routine operator commands

These commands inspect local VM state. They do not scan the archive, create
jobs, or process recordings. Do not paste raw output containing private network
or mount identities into Git or chat.

```bash
systemctl status rosbag-analyser.target --no-pager
systemctl status rosbag-analyser-preflight.service --no-pager
findmnt --mountpoint /srv/rosbag-analyser/source \
  --output TARGET,SOURCE,FSTYPE,FSROOT,OPTIONS,MAJ:MIN
findmnt --mountpoint /var/lib/rosbag-analyser/derived \
  --output TARGET,SOURCE,FSTYPE,FSROOT,OPTIONS,MAJ:MIN,SIZE,AVAIL
curl --fail --silent http://127.0.0.1:8000/health/live
curl --fail --silent http://127.0.0.1:8000/health/ready
```

For service logs, use bounded time windows:

```bash
journalctl -u rosbag-analyser-api.service --since today --no-pager
journalctl -u rosbag-analyser-worker.service --since today --no-pager
```

The supported sanitized evidence command is:

```bash
/opt/rosbag-analyser/current/deploy/scripts/collect-support-bundle \
  /protected/evidence/support-CASE
```

It excludes application environments and journal message bodies. Review the
bundle before sharing it.

## Routine release workflow

Once the initial controlled install is complete, routine source changes travel
through Git and immutable releases; they are never copied to the VM manually.

```text
reviewed change → relevant local tests → commit → push → ./deploy-vm
```

`./deploy-vm` requires a clean local worktree whose `HEAD` exactly matches the
configured remote branch. It asks the VM to fast-forward its dedicated checkout,
build an immutable `git-<revision>` release using the active checked wheelhouse,
activate it atomically, and perform local health and smoke checks.

It is deliberately not a general VM command runner. It refuses migrations,
dependency changes, deployment-template changes, and infrastructure changes;
those require the planned-upgrade procedure in the operator runbook. It also
does not rescan or prepare recordings.

The private workstation settings file is outside Git:

```text
~/.config/rosbag-analyser/vm-deploy.env
```

It contains only the VM SSH endpoint, operator account, branch, and SSH program
path. Its required mode is `0600` or `0400`.

## First response to a problem

1. Record the time, visible symptom, release ID if known, and whether the
   problem affects browsing, processing, or both.
2. Check `rosbag-analyser.target`, preflight, both mount units, and local live
   and ready health using the commands above.
3. Read the bounded API and worker logs. Do not copy raw logs or private paths
   into a ticket/chat.
4. Collect a sanitized support bundle when more evidence is needed.
5. Stop and use the full runbook if the source mount is absent/writable/wrong,
   the derived mount is wrong/full, the database is unavailable, or the problem
   requires a migration, firewall, mount, backup, restore, rollback, reboot, or
   real-source action.

Never fix an incident by editing PostgreSQL rows, changing an active release in
place, deleting derived artifacts to make space, remounting an unreviewed share,
or running a source write probe.

## Live inventory still to be recorded

Before this guide can describe the actual VM rather than the repository model,
the operator must collect and retain the approved private evidence for:

- VM operating-system, package, CPU, memory, disk, time-sync, recovery, and
  boot facts;
- exact source and derived mount identities, read-only evidence, capacity, and
  allowed service ownership;
- active release ID/source revision, PostgreSQL schema, service/target state,
  listener and proxy/firewall evidence;
- backup, restore, certificate, access, capacity, and incident owners; and
- the Gate 0 and real-data-annex approval references.

The read-only Gate 0 command set and evidence rules are in the
[operator runbook](NAS_TRIAL_RUNBOOK.md#gate-0-read-only-audit). Capture that
information outside Git and redact it before sharing for documentation work.
