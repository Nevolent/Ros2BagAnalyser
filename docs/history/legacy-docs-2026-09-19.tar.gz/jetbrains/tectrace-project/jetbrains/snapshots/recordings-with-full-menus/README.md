# Recordings view with full menus

Saved before removing the bottom status bar, right tool rail, and lower-left tools. Includes the resizable folders panel, searchable recordings table, filters, selection, and Prepare selected action.

Open index.html in this folder to view it. To restore, copy index.html, styles.css, and script.js back to jetbrains/.
