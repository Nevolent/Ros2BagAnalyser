# Saved layout before expanding the editor

Open index.html in this folder to view the saved version. It includes the exact HTML, CSS, and JavaScript from before the terminal and database panels were removed.

Original workspace: three columns (29.6fr / 45fr / 24.7fr), two rows (788fr / 382fr), 0.35rem gaps. Terminal spans all three columns. Top offset: 4.6875vh; bottom offset: 3.4375vh; side offsets: 2.9rem. At 2048 × 1280, folders start at (58, 60) and are approximately 572 × 787; editor starts at (637, 60); database starts at (1513, 60); terminal starts at (58, 854) and is approximately 1932 × 382.

To restore this version, copy index.html, styles.css, and script.js from this folder back into jetbrains/.
